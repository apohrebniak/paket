// Background script for the URL Saver extension
// This script handles any background tasks if needed

// Optional: Log when extension is loaded
console.log('Paket loaded');

// You can add background functionality here if needed in the future
// For example: context menu items, keyboard shortcuts, etc.

